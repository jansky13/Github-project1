var y1 = 60
var y2 = 50
var y3 = 55

var y4 = 70
var y5 = 60
 

function setup() {
  createCanvas(400, 400);
  background(10,10,70);

}

function draw(){
  background(10,10,70);
  print('The value of y4 is' + y4)
  snowfall1();
  snowfall2();
  angleMode(RADIANS);
  building1();
  push();
  translate(200,0);
  noStroke();
  fill(100,64,60);
  rect(20,200,100,270);
  stroke(255);
  strokeWeight(2);
  fill(230);
  rect(40,210,20,20);
  rect(40,240,20,20);
  rect(40,270,20,20);
  rect(40,300,20,20);
  rect(40,330,20,20);
  rect(40,360,20,20);
  rect(40,390,20,20);
  rect(80,210,20,20);
  rect(80,240,20,20);
  rect(80,270,20,20);
  rect(80,300,20,20);
  rect(80,330,20,20);
  rect(80,360,20,20);
  rect(80,390,20,20);
  pop();
  cloud1();
  translate(270, 30);
  scale(0.8);
  cloud2();
  translate(-300,30);
  push();
  translate(100,-40)
  rotate(PI / 6.0)
  moon();
  pop();
}

function building1(){
noStroke();
fill(92,64,51);
rect(20,250,100,200);
stroke(255);
strokeWeight(2);
fill(230);
rect(40,270,20,20);
rect(40,300,20,20);
rect(40,330,20,20);
rect(40,360,20,20);
rect(40,390,20,20);
rect(80,270,20,20);
rect(80,300,20,20);
rect(80,330,20,20);
rect(80,360,20,20);
rect(80,390,20,20);
}


function moon(){
strokeWeight(2);
stroke(255,255,255);
fill(210,210,210);
arc(200, 50, 80, 80, 0, PI + QUARTER_PI, PIE);

}

function snowfall2(){
y4=y4+.3
y5=y5+.4
noStroke();
fill(250)
ellipse(280,y4,10,10);
ellipse(340,y5,10,10);

}

function snowfall1(){
  y1=y1+.5
  y2=y2+.3
  y3=y3+.4
  noStroke();
  fill(250)
ellipse(20,y1,10,10);
ellipse(60,y2,10,10);
ellipse(95,y3,10,10);
}


function cloud1(){
  noStroke();
  fill(240,240,240);
  ellipse(50,50,50,50);
  ellipse(80,50,50,50);
  ellipse(50,80,50,50);
  ellipse(80,80,50,50);
  ellipse(30,65,50,50);
  ellipse(100,65,50,50);
}

function cloud2(){
  noStroke();
  fill(240,240,240);
  ellipse(50,50,50,50);
  ellipse(80,50,50,50);
  ellipse(50,80,50,50);
  ellipse(80,80,50,50);
  ellipse(30,65,50,50);
  ellipse(100,65,50,50);
}