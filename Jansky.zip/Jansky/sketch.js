function setup() {
createCanvas(500, 500);
background(10);
}

function draw() {
noStroke();
colorMode(RGB, 255, 255, 255, 1);
fill(130, 80, 190);
ellipse(54, 50, 100, 100);

noFill();
stroke(190, 10, 190);
strokeWeight (4);
curve(0, 50, 0, 50, 130, 50, 100, 50);

noStroke();
colorMode(RGB, 255, 255, 255, .7);
fill(255, 0, 40);
ellipse(380, 110, 200, 200);

noStroke();
fill(205, 0, 40);
ellipse(330, 140, 30, 30);

noStroke();
fill(205, 0, 40);
ellipse(390, 70, 40, 40);

noStroke();
fill(205, 0, 40);
ellipse(330, 70, 20, 20);

noStroke();
fill(205, 0, 40);
ellipse(400, 180, 20, 20);

noStroke();
fill(205, 0, 40);
ellipse(440, 120, 30, 30);

strokeWeight(4);
stroke(40,140,70);
colorMode(RGB, 255, 255, 255, .5);
fill(130, 140, 100);
ellipse(120, 370, 180, 180);

noFill();
strokeWeight(4);
stroke(40,140,70);
ellipse(80, 410, 30, 30);

noFill();
strokeWeight(4);
stroke(40,140,70);
ellipse(102, 333, 20, 20);

noFill();
strokeWeight(4);
stroke(40,140,70);
ellipse(150, 370, 40, 40);

noFill();
strokeWeight(4);
stroke(40,140,70);
ellipse(157, 412, 15, 15);

noFill();
strokeWeight(4);
stroke(40,140,70);
ellipse(75, 370, 15, 15);

noFill();
strokeWeight(4);
stroke(40,140,70);
ellipse(163, 320, 15, 15);

//burners
noStroke();
fill(255, 20, 0);
strokeWeight(4);
triangle(389, 380, 425, 380, 418, 350);

fill(25);
strokeWeight(4);
stroke(45);
triangle(390, 380, 418, 350, 370, 330);

noStroke();
fill(0, 0, 60);
quad(260, 420, 300, 380, 340, 420, 300, 460);

noStroke();
colorMode(RGB, 100, 100, 100, 1);
fill(0, 0, 90);
ellipse(300, 420, 50, 50);

stroke(220)
strokeWeight(2);
point(360,320);
point(350,310);
point(340,300);
point(300,260);
point(290,250);
point(280,240);
point(240,200);
point(230,190);
point(220,180);
}
